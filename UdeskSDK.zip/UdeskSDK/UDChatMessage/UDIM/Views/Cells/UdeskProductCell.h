//
//  UdeskProductCell.h
//  UdeskSDK
//
//  Created by xuchen on 16/8/17.
//  Copyright © 2016年 xuchen. All rights reserved.
//

#import "UdeskBaseCell.h"

@interface UdeskProductCell : UdeskBaseCell

@end
