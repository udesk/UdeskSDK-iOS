//
//  UdeskTipsCell.h
//  UdeskSDK
//
//  Created by xuchen on 16/8/12.
//  Copyright © 2016年 xuchen. All rights reserved.
//

#import "UdeskBaseCell.h"

@class UdeskTipsMessage;

@interface UdeskTipsCell : UdeskBaseCell

@end
