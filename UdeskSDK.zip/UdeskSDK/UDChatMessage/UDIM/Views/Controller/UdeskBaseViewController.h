//
//  UdeskFatherViewController.h
//  UdeskSDK
//
//  Created by Mac开发机 on 2016/12/1.
//  Copyright © 2016年 xuchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UdeskSDKConfig;
@interface UdeskBaseViewController : UIViewController

- (void)dismissChatViewController;

@end
