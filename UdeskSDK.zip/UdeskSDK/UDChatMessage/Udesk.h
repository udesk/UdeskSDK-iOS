//
//  Udesk.h
//  UdeskSDK
//
//  Created by xuchen on 16/6/15.
//  Copyright © 2016年 xuchen. All rights reserved.
//

#ifndef Udesk_h
#define Udesk_h

#import "UdeskManager.h"
#import "UdeskSDKManager.h"

#endif /* Udesk_h */
