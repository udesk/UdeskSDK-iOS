//
//  UdeskSDKStyleBlue.h
//  UdeskSDK
//
//  Created by xuchen on 16/8/29.
//  Copyright © 2016年 xuchen. All rights reserved.
//

#import "UdeskSDKStyle.h"

@interface UdeskSDKStyleBlue : UdeskSDKStyle

@end
