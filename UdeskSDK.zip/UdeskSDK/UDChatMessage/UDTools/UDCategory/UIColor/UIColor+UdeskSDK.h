//
//  UIColor+UdeskSDK.h
//  UdeskSDK
//
//  Created by xuchen on 16/8/16.
//  Copyright © 2016年 xuchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (UdeskSDK)

//16进制颜色转换
+ (UIColor *)colorWithHexString:(NSString *)color;

@end
