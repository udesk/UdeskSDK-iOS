//
//  UITextView+UDTextView.m
//  UdeskSDK
//
//  Created by xuchen on 16/9/12.
//  Copyright © 2016年 xuchen. All rights reserved.
//

#import "UITextView+UDTextView.h"

@implementation UITextView (UDTextView)

- (void)_firstBaselineOffsetFromTop {
    
}

- (void)_baselineOffsetFromBottom {
    
}


@end
