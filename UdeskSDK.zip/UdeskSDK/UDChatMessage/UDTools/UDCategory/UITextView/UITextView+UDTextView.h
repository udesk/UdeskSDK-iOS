//
//  UITextView+UDTextView.h
//  UdeskSDK
//
//  Created by xuchen on 16/9/12.
//  Copyright © 2016年 xuchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextView (UDTextView)

@end
